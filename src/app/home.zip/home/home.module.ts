import { NgModule } from '@angular/core';
import { routing } from "./home.routing";
import { HomeComponent } from "./home.component";
import { ChartModule } from 'angular-highcharts';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [routing, ChartModule, CommonModule],
  declarations: [HomeComponent]
})
export class HomeModule { }