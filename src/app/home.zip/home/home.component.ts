import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { Subscription } from 'rxjs/Subscription';
import { Chart } from 'angular-highcharts';
import { AuthGuard } from '../canactivate.service';
declare var $;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;
  showGate: any = 'false';
  constructor(private getsession: AuthGuard, private getdata: DatatransferService, private router: Router, private makeapi: WebserviceService, private apiurl: DatatransferService, private http: Http) {

  }

  private getSalesReport = this.apiurl.appconstant + 'getSandOReport';

  ngOnInit() {
    $('[data-toggle="tooltip"]').tooltip();
    this.logintype = this.getsession.session().name;
    console.log(this.logintype)
    if (this.logintype === 'admin' || this.logintype === 'gate2') {
      this.showGate = 'true';
    } else {
      this.showGate = 'false';
    }
  }

  individual_performance() {
    this.router.navigateByUrl('/dashboard/individual-performance');
  }

  unique_aggregate() {
    this.router.navigateByUrl('/dashboard/unique-aggregate');
  }
  unique_parts() {
    this.router.navigateByUrl('/dashboard/unique-parts-flow');
  }

  updatestatus() {
    this.getdata.showNotification('bottom', 'right', 'File Uploaded Successfully.', 'success');
  }

  update() {
    this.getdata.showNotification('bottom', 'right', 'Status changed to On-Hold ', 'success');
  }
  approve() {
    this.getdata.showNotification('bottom', 'right', 'Approved!  ', 'success');
  }
  editLive() {
    $('#myModal').modal('show');
  }

  gateConfirm() {
    $('#gateConfirm').modal('show');
  }

}
